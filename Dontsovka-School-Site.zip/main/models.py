from django.db import models

class News(models.Model):
    path = models.URLField('Путь в виде ссылки')
    title = models.CharField('Заголовок', max_length=200)
    description = models.TextField('Описание')
    date = models.DateField("Дата создания", default="2023-01-01")
    url = models.CharField('Ссылка к новосте', default="news", max_length=100)

    def __str__(self) -> str:
        return self.path
